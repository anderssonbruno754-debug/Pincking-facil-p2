# PickFácil — Coleta Profissional Corrigida

Versão 1.6.

Correções desta versão:
- Corrigida a navegação para Histórico de coletas.
- Implementado o salvamento do pedido finalizado no histórico ao tocar em PEDIDO OK.
- Implementado DESFAZER PEDIDO, restaurando as quantidades baixadas no estoque.
- Corrigido o uso dos parâmetros de margem do layout na tela inicial.
- Mantida a coleta profissional com barra de progresso, posição atual em destaque e botão PRÓXIMO.
- Mantidos cadastro de produtos, múltiplos lotes, posições, leitura de nota por foto e baixa automática.

## Gerar APK
Use GitHub Actions e execute o workflow **Gerar APK Pick Fácil**. O APK será publicado como artefato.
