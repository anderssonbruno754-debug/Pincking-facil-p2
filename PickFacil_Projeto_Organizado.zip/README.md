# Pick Fácil — Protótipo Android

Projeto Android organizado para o primeiro teste do aplicativo de picking.

Fluxo atual:
1. Nota fiscal simulada
2. Produtos da nota
3. Quantidade
4. Posição no estoque
5. Confirmação do item separado
6. Progresso do picking

Produtos de exemplo:
- Arroz 5 kg — A-01-03 — 2
- Feijão 1 kg — A-02-01 — 4
- Açúcar 1 kg — B-01-02 — 3
- Café 500 g — B-03-05 — 1

Próxima versão: câmera/OCR da NF-e, código de barras, banco de dados e cadastro real de posições.
