package com.pickfacil.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout box;
    final ArrayList<Product> products = new ArrayList<>();
    int separated = 0;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        loadProducts();
        home();
    }

    void loadProducts() {
        products.clear();
        products.add(new Product("789100000001","Arroz 5 kg",2,"A-01-03"));
        products.add(new Product("789100000002","Feijão 1 kg",4,"A-02-01"));
        products.add(new Product("789100000004","Açúcar 1 kg",3,"B-01-02"));
        products.add(new Product("789100000003","Café 500 g",1,"B-03-05"));
        Collections.sort(products, (a,b) -> a.pos.compareTo(b.pos));
    }

    TextView text(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(Color.DKGRAY);
        v.setPadding(8,14,8,14); return v;
    }

    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(16); return b;
    }

    void base(String title) {
        ScrollView scroll = new ScrollView(this);
        box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24,28,24,24); scroll.addView(box); setContentView(scroll);
        box.addView(text("📦 " + title,26));
        box.addView(text("Pick Fácil • Protótipo 1.0",13));
    }

    void home() {
        base("Picking por Nota Fiscal");
        box.addView(text("Protótipo para localizar produtos durante o picking.",18));
        Button read=button("📷 Ler nota fiscal");
        read.setOnClickListener(v -> note()); box.addView(read);
        Button pick=button("📍 Abrir picking de exemplo");
        pick.setOnClickListener(v -> picking()); box.addView(pick);
        Button cat=button("🗃️ Produtos e posições");
        cat.setOnClickListener(v -> catalog()); box.addView(cat);
        box.addView(text("\nDados de demonstração:\nArroz 5 kg → A-01-03\nFeijão 1 kg → A-02-01\nAçúcar 1 kg → B-01-02\nCafé 500 g → B-03-05\n\nA leitura real da NF-e será adicionada na próxima versão.",15));
    }

    void note() {
        base("Ler nota fiscal");
        box.addView(text("📄 Leitura simulada da NF-e 000123\n4 itens encontrados • 10 unidades",17));
        Button use=button("✅ Usar esta nota no picking");
        use.setOnClickListener(v -> picking()); box.addView(use);
        Button back=button("⬅ Voltar");
        back.setOnClickListener(v -> home()); box.addView(back);
    }

    void picking() {
        base("Picking • NF-e 000123");
        TextView progress=text("Progresso: "+separated+"/"+products.size()+" produtos",18);
        box.addView(progress);
        for (Product p: products) {
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.addView(text(p.name+" • "+p.qty+" un.",19));
            card.addView(text("📍 Posição: "+p.pos+"\nCódigo: "+p.code,16));
            Button ok=button(p.done ? "✅ Separado" : "Marcar como separado");
            ok.setEnabled(!p.done);
            ok.setOnClickListener(v -> {
                if (!p.done) {
                    p.done=true; separated++;
                    ok.setText("✅ Separado"); ok.setEnabled(false);
                    progress.setText("Progresso: "+separated+"/"+products.size()+" produtos");
                }
            });
            card.addView(ok); box.addView(card);
        }
        Button back=button("⬅ Voltar");
        back.setOnClickListener(v -> home()); box.addView(back);
    }

    void catalog() {
        base("Produtos e posições");
        for (Product p: products)
            box.addView(text("Código: "+p.code+"\nProduto: "+p.name+"\n📍 "+p.pos+"\n",17));
        Button back=button("⬅ Voltar");
        back.setOnClickListener(v -> home()); box.addView(back);
    }

    static class Product {
        String code,name,pos; int qty; boolean done;
        Product(String c,String n,int q,String p){code=c;name=n;qty=q;pos=p;}
    }
}
