# Pick Fácil — Protótipo Android

Projeto Android organizado para o aplicativo de picking.

Versão 1.1: tela profissional de busca de produtos, com filtro por nome/código/posição e exibição automática da posição e quantidade.

Fluxo atual:
1. Nota fiscal simulada
2. Produtos da nota
3. Quantidade
4. Posição no estoque
5. Confirmação do item separado
6. Progresso do picking

Produtos de exemplo:
- Arroz 5 kg — A-01-03 — 2
- Feijão 1 kg — A-02-01 — 4
- Açúcar 1 kg — B-01-02 — 3
- Café 500 g — B-03-05 — 1

Próximas versões: câmera/OCR da NF-e, leitura de código de barras, banco de dados e cadastro real de posições.
