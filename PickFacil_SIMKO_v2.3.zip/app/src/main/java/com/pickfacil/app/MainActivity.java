package com.pickfacil.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import androidx.exifinterface.media.ExifInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.MotionEvent;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 7001;
    private Uri pendingPhotoUri;
    // Aba atual para permitir navegação por gesto (deslize).
    private int currentPage = 0; // 0=Início, 1=Coletar, 2=Estoque, 3=Histórico

    private LinearLayout box;
    private EditText searchInput;
    private TextView resultCount;
    private final ArrayList<Product> products = new ArrayList<>();
    private SharedPreferences prefs;

    private final int NAVY = Color.rgb(11, 31, 70);
    private final int BLUE = Color.rgb(18, 84, 196);
    private final int YELLOW = Color.rgb(255, 193, 7);
    private final int DARK = Color.rgb(17, 24, 39);
    private final int GRAY = Color.rgb(107, 114, 128);
    private final int LIGHT = Color.rgb(245, 248, 253);
    private final int GREEN = Color.rgb(22, 163, 74);
    private final int RED = Color.rgb(220, 38, 38);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLUE);
        prefs = getSharedPreferences("pickfacil", MODE_PRIVATE);
        loadProducts();
        home();
    }

    private void loadProducts() {
        products.clear();
        String raw = prefs.getString("products", "");
        try {
            if (!raw.isEmpty()) {
                JSONArray array = new JSONArray(raw);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    Product product = new Product(object.optString("code"), object.optString("name"));
                    JSONArray lots = object.optJSONArray("lots");
                    if (lots != null) {
                        for (int j = 0; j < lots.length(); j++) {
                            JSONObject lotObject = lots.getJSONObject(j);
                            product.lots.add(new Lot(lotObject.optString("lot"), lotObject.optString("pos"), lotObject.optInt("qty", 0)));
                        }
                    }
                    products.add(product);
                }
            }
            seedOfficialCatalog();
        } catch (Exception ignored) {
            products.clear();
            seedOfficialCatalog();
        }
        sortProducts();
    }

    // Catálogo inicial fornecido pelo usuário. Quando não há estoque salvo,
    // cada item recebe quantidade 1, conforme a regra definida para cadastros sem quantidade.
    // Se já houver dados no aparelho, somente produtos ainda ausentes são adicionados.
    private void seedOfficialCatalog() {
        final String LOT = "Não informado";
        addCatalogProduct("Durasterida", "10.1", LOT);
        addCatalogProduct("Progesterona", "10.2", LOT);
        addCatalogProduct("Guaraná", "10.3", LOT);
        addCatalogProduct("Subgalato 100g", "10.4", LOT);
        addCatalogProduct("Sorbato", "10.5", LOT);
        addCatalogProduct("Sucupira", "10.6", LOT);
        addCatalogProduct("Prolanza 100g", "10.7", LOT);
        addCatalogProduct("Prolanza 250g", "10.8", LOT);
        addCatalogProduct("Timol", "10.9", LOT);
        addCatalogProduct("Pectina", "10.10", LOT);
        addCatalogProduct("Hidroxi", "10.11", LOT);
        addCatalogProduct("Leanmass", "10.12", LOT);
        addCatalogProduct("Vitamina C", "10.13", LOT);
        addCatalogProduct("Vitamina C", "10.14", LOT);

        addCatalogProduct("Uxi amarelo", "9.1", LOT);
        addCatalogProduct("Resorcina", "9.2", LOT);
        addCatalogProduct("Pepsina", "9.3", LOT);
        addCatalogProduct("Pear tomato 250g", "9.4", LOT);
        addCatalogProduct("Pearl tomato 1kg", "9.5", LOT);
        addCatalogProduct("Subgalato 250g", "9.6", LOT);
        addCatalogProduct("Pfaffia", "9.7", LOT);
        addCatalogProduct("Psylium", "9.8", LOT);
        addCatalogProduct("Prolanza 1kg", "9.9", LOT);
        addCatalogProduct("Microsmin 100g", "9.10", LOT);
        addCatalogProduct("Urucum", "9.11", LOT);
        addCatalogProduct("Dissulfiram", "9.12", LOT);
        addCatalogProduct("PQQ", "9.13", LOT);
        addCatalogProduct("Selmet", "9.14", LOT);

        addCatalogProduct("Óleo de amendoim", "8.1", LOT);
        addCatalogProduct("Óleo de maracujá", "8.2", LOT);
        addCatalogProduct("Óleo de menta", "8.3", LOT);
        addCatalogProduct("Licopeno", "8.4", LOT);
        addCatalogProduct("Faseolamina", "8.5", LOT);
        addCatalogProduct("Cranberry", "8.6", LOT);
        addCatalogProduct("Pioglitazona", "8.7", LOT);
        addCatalogProduct("Olmesartana", "8.8", LOT);
        addCatalogProduct("N-acetil (NAC) 2kg", "8.9", LOT);
        addCatalogProduct("Lactose", "8.10", LOT);
        addCatalogProduct("Lactose", "8.11", LOT);
        addCatalogProduct("Microsmin 250g", "8.12", LOT);
        addCatalogProduct("Óleo de coco", "8.13", LOT);
        addCatalogProduct("Papaína", "8.14", LOT);

        addCatalogProduct("Óleo de girassol", "7.1", LOT);
        addCatalogProduct("Óleo de abóbora", "7.2", LOT);
        addCatalogProduct("Óleo de argan", "7.3", LOT);
        addCatalogProduct("Cânfora", "7.4", LOT);
        addCatalogProduct("Óleo de orégano", "7.5", LOT);
        addCatalogProduct("Óleo de cenoura", "7.6", LOT);
        addCatalogProduct("Óleo de abacate", "7.7", LOT);
        addCatalogProduct("Óleo de gergelim", "7.8", LOT);
        addCatalogProduct("Óleo de framboesa", "7.9", LOT);
        addCatalogProduct("Óleo de rosa", "7.10", LOT);
        addCatalogProduct("Óleo de calêndula", "7.11", LOT);
        addCatalogProduct("Óleo de linhaça", "7.12", LOT);
        addCatalogProduct("Óleo de amêndoas", "7.13", LOT);
        addCatalogProduct("Óleo de urucum", "7.14", LOT);

        addCatalogProduct("B.control 100g", "6.1", LOT);
        addCatalogProduct("Gymnema 1kg", "6.2", LOT);
        addCatalogProduct("Gymnema 250g", "6.3", LOT);
        addCatalogProduct("B.control 250g", "6.4", LOT);
        addCatalogProduct("N-acetil (NAC) 1kg", "6.5", LOT);
        addCatalogProduct("Citicolina", "6.6", LOT);
        addCatalogProduct("Ferro", "6.7", LOT);
        addCatalogProduct("Celulose 102", "6.8", LOT);
        addCatalogProduct("Bezafibrato", "6.9", LOT);
        addCatalogProduct("Magnésio inositol", "6.10", LOT);
        addCatalogProduct("Panax 250g", "6.11", LOT);
        addCatalogProduct("Panax 1kg", "6.12", LOT);
        addCatalogProduct("Ashwagandha", "6.13", LOT);
        addCatalogProduct("Óleo de uva", "6.14", LOT);

        addCatalogProduct("Coenzima Q10", "5.1", LOT);
        addCatalogProduct("Magnésio bisglicinato", "5.2", LOT);
        addCatalogProduct("Magnésio malato", "5.3", LOT);
        addCatalogProduct("Magnésio taurato", "5.4", LOT);
        addCatalogProduct("Magma treo", "5.5", LOT);
        addCatalogProduct("Cálcio citrato", "5.6", LOT);
        addCatalogProduct("Manganês bisglicinato", "5.7", LOT);
        addCatalogProduct("Microsmin 1kg", "5.8", LOT);
        addCatalogProduct("Molibdênio", "5.9", LOT);
        addCatalogProduct("Magnésio dimalato", "5.10", LOT);
        addCatalogProduct("Sene", "5.11", LOT);
        addCatalogProduct("Sulfato de zinco", "5.12", LOT);
        addCatalogProduct("Cúrcuma", "5.13", LOT);
        addCatalogProduct("Minoxidil", "5.14", LOT);

        addCatalogProduct("Feno-grego", "4.1", LOT);
        addCatalogProduct("Famotidina", "4.2", LOT);
        addCatalogProduct("Gluconato de zinco", "4.3", LOT);
        addCatalogProduct("Diacereína", "4.4", LOT);
        addCatalogProduct("L-arginina base", "4.5", LOT);
        addCatalogProduct("Folinato de cálcio", "4.6", LOT);
        addCatalogProduct("Goma xantana", "4.7", LOT);
        addCatalogProduct("Iodeto de potássio", "4.8", LOT);
        addCatalogProduct("Lifenol 100g", "4.9", LOT);
        addCatalogProduct("Lifenol 500g", "4.10", LOT);
        addCatalogProduct("Long jack", "4.11", LOT);
        addCatalogProduct("Hidroquinona", "4.12", LOT);
        addCatalogProduct("Glucosamina", "4.13", LOT);
        addCatalogProduct("Maca peruana", "4.14", LOT);

        addCatalogProduct("Empagliflozina", "3.1", LOT);
        addCatalogProduct("Betteral 250g", "3.2", LOT);
        addCatalogProduct("D-ribose", "3.3", LOT);
        addCatalogProduct("Zinco", "3.4", LOT);
        addCatalogProduct("Estrog100 1kg", "3.5", LOT);
        addCatalogProduct("Estrog100 250g", "3.6", LOT);
        addCatalogProduct("Eubone 250g", "3.7", LOT);
        addCatalogProduct("Eubone 1kg", "3.8", LOT);
        addCatalogProduct("Evans cuidado íntimo", "3.9", LOT);
        addCatalogProduct("Evans intravaginal", "3.10", LOT);
        addCatalogProduct("Cloreto de alumínio", "3.11", LOT);
        addCatalogProduct("Ezetimibe", "3.12", LOT);
        addCatalogProduct("Orlistate 1kg", "3.13", LOT);
        addCatalogProduct("Cloreto de potássio", "3.14", LOT);

        addCatalogProduct("Cavalinha", "2.1", LOT);
        addCatalogProduct("Ciprofibrato", "2.2", LOT);
        addCatalogProduct("Cítrus 1kg", "2.3", LOT);
        addCatalogProduct("Clorela", "2.4", LOT);
        addCatalogProduct("Cobre", "2.5", LOT);
        addCatalogProduct("Celulose 101", "2.6", LOT);
        addCatalogProduct("Cyanotis 50g", "2.7", LOT);
        addCatalogProduct("Cyanotis 100g", "2.8", LOT);
        addCatalogProduct("Tofacitinibe", "2.9", LOT);
        addCatalogProduct("Cordia", "2.10", LOT);
        addCatalogProduct("Cratavin 1kg", "2.11", LOT);
        addCatalogProduct("Cratavin 250g", "2.12", LOT);
        addCatalogProduct("Condroitina", "2.13", LOT);
        addCatalogProduct("Cálcio bisglicinato", "2.14", LOT);

        addCatalogProduct("Acerola", "1.1", LOT);
        addCatalogProduct("Betteral 100g", "1.2", LOT);
        addCatalogProduct("Alopurinol", "1.3", LOT);
        addCatalogProduct("ATA MG 1kg", "1.4", LOT);
        addCatalogProduct("ATA MG 250g", "1.5", LOT);
        addCatalogProduct("Benfotiamina", "1.6", LOT);
        addCatalogProduct("Betteral 1kg", "1.7", LOT);
        addCatalogProduct("Brócolis", "1.8", LOT);
        addCatalogProduct("B.control 1kg", "1.9", LOT);
        addCatalogProduct("Orlistate 250g", "1.10", LOT);
        addCatalogProduct("Ácido tricloroacético", "1.11", LOT);
        addCatalogProduct("Benzoato", "1.12", LOT);
        addCatalogProduct("Cloroquina", "1.13", LOT);
        addCatalogProduct("Carqueja", "1.14", LOT);
        saveProducts();
    }

    private void addCatalogProduct(String name, String position, String lotName) {
        for (Product existing : products) {
            if (existing.name.equalsIgnoreCase(name)) {
                for (Lot lot : existing.lots) {
                    if (lot.pos.equals(position)) return;
                }
                existing.lots.add(new Lot(lotName, position, 1));
                return;
            }
        }
        Product product = new Product("", name);
        product.lots.add(new Lot(lotName, position, 1));
        products.add(product);
    }

    private Product sampleProduct(String code, String name, String position, int quantity) {
        Product product = new Product(code, name);
        product.lots.add(new Lot("Lote exemplo", position, quantity));
        return product;
    }

    private void sortProducts() {
        Collections.sort(products, (a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    private void saveProducts() {
        try {
            JSONArray array = new JSONArray();
            for (Product product : products) {
                JSONObject object = new JSONObject();
                object.put("code", product.code);
                object.put("name", product.name);
                JSONArray lots = new JSONArray();
                for (Lot lot : product.lots) {
                    JSONObject lotObject = new JSONObject();
                    lotObject.put("lot", lot.lot);
                    lotObject.put("pos", lot.pos);
                    lotObject.put("qty", lot.qty);
                    lots.put(lotObject);
                }
                object.put("lots", lots);
                array.put(object);
            }
            prefs.edit().putString("products", array.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private TextView label(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(dp(4), dp(4), dp(4), dp(4));
        return view;
    }

    private TextView title(String text, float size) {
        TextView view = label(text, size, DARK);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackground(background(BLUE, 12));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        return button;
    }

    private Button dangerButton(String text) {
        Button button = actionButton(text);
        button.setBackground(background(RED, 12));
        return button;
    }

    private void base(String screenTitle, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(LIGHT);

        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(20));
        scroll.addView(box);

        // Navegação por gesto: deslize para a direita para a próxima aba
        // e para a esquerda para a aba anterior. O gesto só é acionado
        // quando for claramente horizontal, preservando a rolagem vertical.
        final float[] down = {0f, 0f};
        scroll.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                down[0] = event.getX();
                down[1] = event.getY();
                return false;
            }
            if (event.getAction() == MotionEvent.ACTION_UP) {
                float dx = event.getX() - down[0];
                float dy = event.getY() - down[1];
                if (Math.abs(dx) > dp(100) && Math.abs(dx) > Math.abs(dy) * 1.35f) {
                    if (dx > 0) {
                        swipeToPage(currentPage + 1);
                    } else {
                        swipeToPage(currentPage - 1);
                    }
                    return true;
                }
            }
            return false;
        });
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(6), dp(6), dp(6), dp(12));
        TextView company = title("SIM.KO", 13);
        company.setTextColor(YELLOW);
        company.setLetterSpacing(0.08f);
        header.addView(company);
        TextView t = title(screenTitle, 24);
        header.addView(t);
        header.addView(label(subtitle, 13, GRAY));
        box.addView(header);
    }

    private TextView statCard(String big, String small, int accent) {
        TextView card = new TextView(this);
        card.setText(big + "\n" + small);
        card.setTextSize(14);
        card.setTextColor(DARK);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable bg = background(Color.WHITE, 16);
        bg.setStroke(dp(2), accent);
        card.setBackground(bg);
        return card;
    }

    private void home() {
        currentPage = 0;
        base("PickFácil", "Seu assistente de separação de pedidos");

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{NAVY, BLUE});
        heroBg.setCornerRadius(dp(22));
        hero.setBackground(heroBg);
        TextView heroTitle = new TextView(this);
        heroTitle.setText("Olá! 👋\nVamos separar pedidos?");
        heroTitle.setTextSize(23);
        heroTitle.setTextColor(Color.WHITE);
        heroTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hero.addView(heroTitle);
        TextView heroSub = new TextView(this);
        heroSub.setText("Fotografe a nota e deixe o PickFácil organizar a coleta.");
        heroSub.setTextSize(14);
        heroSub.setTextColor(Color.WHITE);
        heroSub.setPadding(0, dp(6), 0, 0);
        hero.addView(heroSub);
        box.addView(hero, marginParams(0, 2, 0, 14));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        TextView s1 = statCard(String.valueOf(products.size()), "Produtos", BLUE);
        int lotCount = 0, units = 0;
        for (Product p : products) for (Lot l : p.lots) { lotCount++; units += Math.max(0, l.qty); }
        TextView s2 = statCard(String.valueOf(lotCount), "Lotes", GREEN);
        TextView s3 = statCard(String.valueOf(units), "Unidades", RED);
        stats.addView(s1, new LinearLayout.LayoutParams(0, dp(72), 1));
        stats.addView(s2, new LinearLayout.LayoutParams(0, dp(72), 1));
        stats.addView(s3, new LinearLayout.LayoutParams(0, dp(72), 1));
        box.addView(stats, marginParams(0, 0, 0, 16));

        box.addView(sectionTitle("Ações rápidas"));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button photo = actionButton("📷\nLer nota\npor foto");
        photo.setTextSize(15);
        photo.setMinHeight(dp(105));
        photo.setOnClickListener(v -> startPhotoCollection());
        Button register = actionButton("➕\nNovo\nproduto");
        register.setTextSize(15);
        register.setMinHeight(dp(105));
        register.setOnClickListener(v -> newProduct());
        row1.addView(photo, new LinearLayout.LayoutParams(0, dp(105), 1));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(0, dp(105), 1);
        rlp.setMargins(dp(8), 0, 0, 0);
        row1.addView(register, rlp);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button stock = actionButton("📦\nEstoque\ne lotes");
        stock.setTextSize(15);
        stock.setMinHeight(dp(105));
        stock.setOnClickListener(v -> catalog());
        Button history = actionButton("🕘\nHistórico\nde coletas");
        history.setTextSize(15);
        history.setMinHeight(dp(105));
        history.setOnClickListener(v -> collectionHistory());
        row2.addView(stock, new LinearLayout.LayoutParams(0, dp(105), 1));
        LinearLayout.LayoutParams historyParams = new LinearLayout.LayoutParams(0, dp(105), 1);
        historyParams.setMargins(dp(8), 0, 0, 0);
        row2.addView(history, historyParams);

        grid.addView(row1, marginParams(0, 0, 0, 8));
        grid.addView(row2);
        box.addView(grid, marginParams(0, 0, 0, 12));

        LinearLayout tip = new LinearLayout(this);
        tip.setOrientation(LinearLayout.VERTICAL);
        tip.setPadding(dp(14), dp(12), dp(14), dp(12));
        tip.setBackground(background(Color.WHITE, 16));
        tip.addView(title("💡 Dica rápida", 16));
        tip.addView(label("Cadastre os lotes com posição e quantidade. Depois, fotografe a nota para montar a rota de coleta automaticamente.", 13, GRAY));
        box.addView(tip, marginParams(0, 0, 0, 4));

    }

    private void swipeToPage(int page) {
        if (page < 0 || page > 3) return;
        if (page == 0) home();
        else if (page == 1) collectLanding();
        else if (page == 2) catalog();
        else collectionHistory();
    }

    private void collectLanding() {
        currentPage = 1;
        base("Coletar", "Fotografe a nota e siga a coleta inteligente");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(22), dp(20), dp(22));
        card.setBackground(background(Color.WHITE, 20));

        TextView icon = title("📷", 42);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        TextView heading = title("Começar uma coleta", 22);
        heading.setGravity(Gravity.CENTER);
        card.addView(heading, marginParams(0, 8, 0, 6));

        TextView desc = label("Tire uma foto da nota. O PickFácil lê os produtos cadastrados e monta a rota de coleta por posição.", 14, GRAY);
        desc.setGravity(Gravity.CENTER);
        card.addView(desc);

        Button photo = actionButton("📷 LER NOTA POR FOTO");
        photo.setTextSize(17);
        photo.setMinHeight(dp(60));
        photo.setOnClickListener(v -> startPhotoCollection());
        card.addView(photo, marginParams(0, 18, 0, 0));

        box.addView(card, marginParams(0, 8, 0, 16));
        box.addView(label("Deslize para a direita → para Estoque ou para a esquerda ← para Início.", 12, GRAY), marginParams(0, 4, 0, 8));
    }

    private void startPhotoCollection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
            return;
        }
        openCamera();
    }

    private void openCamera() {
        Toast.makeText(this, "Enquadre a nota inteira, mantenha o celular firme e use boa iluminação.", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "Câmera não encontrada neste aparelho.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "pickfacil_nota_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PickFacil");
            pendingPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) {
                Toast.makeText(this, "Não foi possível preparar a foto.", Toast.LENGTH_SHORT).show();
                return;
            }
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
        }

        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Precisamos da câmera para fotografar a nota.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAMERA || resultCode != RESULT_OK) {
            return;
        }

        if (pendingPhotoUri != null) {
            Uri uri = pendingPhotoUri;
            pendingPhotoUri = null;
            processPhoto(uri);
            return;
        }

        if (data != null && data.getExtras() != null) {
            Object value = data.getExtras().get("data");
            if (value instanceof Bitmap) {
                processBitmap((Bitmap) value);
            }
        }
    }

    private void processPhoto(Uri uri) {
        try {
            // Usa a foto em resolução total e aplica uma preparação simples para OCR:
            // rotação correta pelo EXIF, redução de ruído, contraste e nitidez.
            Bitmap source = BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
            if (source == null) throw new IllegalStateException("imagem vazia");
            Bitmap prepared = prepareForOcr(source, uri);
            recognizeText(InputImage.fromBitmap(prepared, 0));
        } catch (Exception e) {
            try {
                InputImage image = InputImage.fromFilePath(this, uri);
                recognizeText(image);
            } catch (Exception ignored) {
                Toast.makeText(this, "Não foi possível abrir a foto da nota.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private Bitmap prepareForOcr(Bitmap source, Uri uri) throws Exception {
        int rotation = 0;
        try {
            ExifInterface exif = new ExifInterface(getContentResolver().openInputStream(uri));
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
            else if (orientation == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
        } catch (Exception ignored) {}

        android.graphics.Matrix matrix = new android.graphics.Matrix();
        if (rotation != 0) matrix.postRotate(rotation);
        Bitmap rotated = Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);

        // Mantém alta resolução, mas evita imagens gigantes que podem prejudicar o processamento.
        int max = 3200;
        float scale = Math.min(1f, max / (float) Math.max(rotated.getWidth(), rotated.getHeight()));
        Bitmap scaled = rotated;
        if (scale < 1f) {
            scaled = Bitmap.createScaledBitmap(rotated, Math.max(1, Math.round(rotated.getWidth()*scale)), Math.max(1, Math.round(rotated.getHeight()*scale)), true);
        }

        Bitmap enhanced = Bitmap.createBitmap(scaled.getWidth(), scaled.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0.15f);
        float contrast = 1.25f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        cm.postConcat(new ColorMatrix(new float[]{
                contrast,0,0,0,translate,
                0,contrast,0,0,translate,
                0,0,contrast,0,translate,
                0,0,0,1,0
        }));
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(scaled, 0, 0, paint);
        if (scaled != rotated) rotated.recycle();
        if (scaled != source) scaled.recycle();
        if (source != enhanced) source.recycle();
        return enhanced;
    }

    private void processBitmap(Bitmap bitmap) {
        try {
            recognizeText(InputImage.fromBitmap(bitmap, 0));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível ler a foto.", Toast.LENGTH_LONG).show();
        }
    }

    private void recognizeText(InputImage image) {
        Toast.makeText(this, "Lendo a nota...", Toast.LENGTH_SHORT).show();
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText();
                    recognizer.close();
                    showPhotoResult(text);
                })
                .addOnFailureListener(error -> {
                    recognizer.close();
                    Toast.makeText(this, "Não consegui ler a nota. Tente uma foto mais nítida e bem iluminada.", Toast.LENGTH_LONG).show();
                });
    }

    private void showPhotoResult(String text) {
        if (text == null) text = "";
        String recognized = text.trim();
        ArrayList<PickItem> items = buildPickItems(recognized);
        showPhotoConference(items, recognized);
    }

    private static class ConferenceItem {
        Product product;
        int quantity;
        EditText quantityField;
        ConferenceItem(Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }
    }

    private void showPhotoConference(final ArrayList<PickItem> detectedItems, final String recognized) {
        base("Conferir produtos", "Confira os itens lidos pela foto antes de gerar a coleta.");

        if (detectedItems.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setPadding(dp(18), dp(18), dp(18), dp(18));
            empty.setBackground(background(Color.WHITE, 18));
            empty.addView(title("⚠️ Nenhum produto foi reconhecido", 19));
            empty.addView(label("A foto foi lida, mas nenhum produto da nota foi encontrado no cadastro do SIM.KO. Tente fotografar a nota novamente com mais nitidez.", 14, GRAY), marginParams(0, 8, 0, 0));
            box.addView(empty, marginParams(0, 4, 0, 12));
            Button back = actionButton("📷 FOTOGRAFAR NOVAMENTE");
            back.setOnClickListener(v -> startPhotoCollection());
            box.addView(back, marginParams(0, 0, 0, 8));
            return;
        }

        ArrayList<ConferenceItem> conference = new ArrayList<>();
        for (PickItem item : detectedItems) {
            ConferenceItem existing = null;
            for (ConferenceItem c : conference) {
                if (c.product == item.product) { existing = c; break; }
            }
            if (existing == null) conference.add(new ConferenceItem(item.product, item.quantity));
            else existing.quantity += item.quantity;
        }

        int total = 0;
        for (ConferenceItem c : conference) total += c.quantity;

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(16), dp(14), dp(16), dp(14));
        summary.setBackground(background(Color.WHITE, 16));
        TextView count = title(conference.size() + (conference.size() == 1 ? " produto" : " produtos") + " reconhecidos", 18);
        summary.addView(count);
        TextView units = label(total + (total == 1 ? " unidade" : " unidades") + " encontradas no estoque", 14, GRAY);
        summary.addView(units, marginParams(0, 4, 0, 0));
        box.addView(summary, marginParams(0, 0, 0, 12));

        TextView warning = label("Confira nome e quantidade. Produtos não encontrados no cadastro não entram na coleta.", 13, GRAY);
        box.addView(warning, marginParams(0, 0, 0, 8));

        for (ConferenceItem c : conference) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(15), dp(13), dp(15), dp(13));
            card.setBackground(background(Color.WHITE, 16));
            card.addView(title(c.product.name, 17));
            if (!c.product.code.isEmpty()) card.addView(label("Código: " + c.product.code, 12, GRAY), marginParams(0, 2, 0, 4));

            TextView stock = label("🟢 Produto cadastrado • " + totalStock(c.product) + " un. disponíveis", 13, GREEN);
            card.addView(stock, marginParams(0, 2, 0, 6));

            EditText qty = field("Quantidade");
            qty.setInputType(InputType.TYPE_CLASS_NUMBER);
            qty.setText(String.valueOf(c.quantity));
            qty.setSelectAllOnFocus(true);
            c.quantityField = qty;
            card.addView(qty);
            box.addView(card, marginParams(0, 0, 0, 10));
        }

        Button generate = actionButton("✅ GERAR COLETA");
        generate.setTextSize(17);
        generate.setMinHeight(dp(60));
        generate.setOnClickListener(v -> {
            ArrayList<PickItem> finalItems = new ArrayList<>();
            boolean invalid = false;
            for (ConferenceItem c : conference) {
                int q = 0;
                try { q = Integer.parseInt(c.quantityField.getText().toString().trim()); } catch (Exception ignored) { }
                if (q <= 0) { invalid = true; break; }
                if (totalStock(c.product) < q) {
                    Toast.makeText(this, c.product.name + ": estoque insuficiente. Disponível: " + totalStock(c.product) + " un.", Toast.LENGTH_LONG).show();
                    return;
                }
                c.quantity = q;
                addPickItemsForProduct(finalItems, c.product, q);
            }
            if (invalid || finalItems.isEmpty()) {
                Toast.makeText(this, "Confira as quantidades antes de gerar a coleta.", Toast.LENGTH_SHORT).show();
                return;
            }
            Collections.sort(finalItems, (a, b) -> comparePositions(a.position, b.position));
            showSmartPicking(finalItems, recognized);
        });
        box.addView(generate, marginParams(0, 4, 0, 10));

        Button cancel = actionButton("↩️ Voltar");
        cancel.setOnClickListener(v -> collectLanding());
        box.addView(cancel);
    }

    private int totalStock(Product product) {
        int total = 0;
        for (Lot lot : product.lots) total += Math.max(0, lot.qty);
        return total;
    }

    private int comparePositions(String a, String b) {
        try {
            String[] pa = a.split("\\.");
            String[] pb = b.split("\\.");
            int na = Integer.parseInt(pa[0]);
            int nb = Integer.parseInt(pb[0]);
            if (na != nb) return Integer.compare(nb, na);
            int sa = pa.length > 1 ? Integer.parseInt(pa[1]) : 0;
            int sb = pb.length > 1 ? Integer.parseInt(pb[1]) : 0;
            return Integer.compare(sa, sb);
        } catch (Exception e) {
            return a.compareToIgnoreCase(b);
        }
    }

    private void showSmartPicking(final ArrayList<PickItem> items, final String recognized) {
        base("Coleta inteligente", items.isEmpty()
                ? "Nenhum produto cadastrado foi reconhecido automaticamente."
                : "Siga a rota, confirme a separação e avance para a próxima posição.");

        if (items.isEmpty()) {
            box.addView(label("Não foi possível montar a lista automaticamente.", 16, DARK), marginParams(0, 0, 0, 8));
        } else {
            int totalUnits = 0;
            for (PickItem item : items) totalUnits += item.quantity;

            final int totalItems = items.size();
            final int totalUnitsFinal = totalUnits;
            final int[] current = {0};
            final int[] collectedItems = {0};
            final int[] collectedUnits = {0};

            // Cabeçalho de progresso
            LinearLayout progressCard = new LinearLayout(this);
            progressCard.setOrientation(LinearLayout.VERTICAL);
            progressCard.setPadding(dp(16), dp(14), dp(16), dp(14));
            progressCard.setBackground(background(Color.WHITE, 16));

            TextView progressTitle = title("Coleta 0 de " + totalItems, 18);
            progressCard.addView(progressTitle);

            TextView progressNumbers = label("0% • 0 de " + totalUnitsFinal + " unidades", 13, GRAY);
            progressCard.addView(progressNumbers, marginParams(0, 4, 0, 8));

            ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progressBar.setMax(totalItems * 100);
            progressBar.setProgress(0);
            progressCard.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(10)));
            box.addView(progressCard, marginParams(0, 0, 0, 12));

            // Posição atual em destaque
            LinearLayout positionCard = new LinearLayout(this);
            positionCard.setOrientation(LinearLayout.VERTICAL);
            positionCard.setPadding(dp(18), dp(16), dp(18), dp(16));
            positionCard.setBackground(background(BLUE, 18));

            TextView positionCaption = label("POSIÇÃO ATUAL", 12, Color.WHITE);
            positionCaption.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            positionCard.addView(positionCaption);

            TextView positionValue = title("📍 " + items.get(0).position, 30);
            positionValue.setTextColor(Color.WHITE);
            positionCard.addView(positionValue, marginParams(0, 2, 0, 0));

            TextView positionHint = label("Vá até esta posição para separar o próximo item.", 13, Color.WHITE);
            positionCard.addView(positionHint, marginParams(0, 4, 0, 0));
            box.addView(positionCard, marginParams(0, 0, 0, 12));

            // Item atual
            LinearLayout itemCard = new LinearLayout(this);
            itemCard.setOrientation(LinearLayout.VERTICAL);
            itemCard.setPadding(dp(18), dp(16), dp(18), dp(16));
            itemCard.setBackground(background(Color.WHITE, 18));
            box.addView(itemCard, marginParams(0, 0, 0, 12));

            TextView itemCounter = title("ITEM 1 / " + totalItems, 13);
            itemCounter.setTextColor(BLUE);
            itemCard.addView(itemCounter);

            TextView productTitle = title(items.get(0).product.name, 21);
            itemCard.addView(productTitle, marginParams(0, 6, 0, 8));

            TextView itemDetails = label("🏷️ Lote: " + items.get(0).lot.lot
                    + "\n📦 Separar: " + items.get(0).quantity + " un."
                    + "\n📊 Estoque disponível: " + items.get(0).lot.qty + " un.", 15, DARK);
            itemCard.addView(itemDetails);

            Button collectButton = actionButton("☐ MARCAR COMO COLETADO");
            itemCard.addView(collectButton, marginParams(0, 12, 0, 0));

            Button nextButton = actionButton("PRÓXIMO  →");
            nextButton.setTextSize(18);
            nextButton.setAllCaps(false);
            nextButton.setMinHeight(dp(58));
            nextButton.setEnabled(false);
            box.addView(nextButton, marginParams(0, 0, 0, 12));

            Button finalize = actionButton("📋 PEDIDO OK — FINALIZAR COLETA");
            finalize.setTextSize(16);
            finalize.setAllCaps(false);
            finalize.setEnabled(false);
            box.addView(finalize, marginParams(0, 0, 0, 12));

            TextView instruction = label("Primeiro confirme a separação do item atual.", 13, GRAY);
            instruction.setGravity(Gravity.CENTER);
            box.addView(instruction, marginParams(0, 0, 0, 12));

            Runnable refresh = () -> {
                if (current[0] >= totalItems) return;
                PickItem item = items.get(current[0]);
                positionValue.setText("📍 " + item.position);
                itemCounter.setText("ITEM " + (current[0] + 1) + " / " + totalItems);
                productTitle.setText(item.product.name);
                itemDetails.setText("🏷️ Lote: " + item.lot.lot
                        + "\n📦 Separar: " + item.quantity + " un."
                        + "\n📊 Estoque disponível: " + item.lot.qty + " un.");
                collectButton.setText("☐ MARCAR COMO COLETADO");
                collectButton.setEnabled(true);
                nextButton.setEnabled(false);
                progressTitle.setText("Coleta " + collectedItems[0] + " de " + totalItems);
                int percent = (int) Math.round((collectedItems[0] * 100.0) / totalItems);
                progressNumbers.setText(percent + "% • " + collectedUnits[0] + " de " + totalUnitsFinal + " unidades");
                progressBar.setProgress(collectedItems[0] * 100);
                instruction.setText("📍 Siga para " + item.position + " e confirme a separação.");
            };

            collectButton.setOnClickListener(v -> {
                if (!collectButton.isEnabled() || current[0] >= totalItems) return;
                PickItem item = items.get(current[0]);
                if (item.lot.qty < item.quantity) {
                    Toast.makeText(this, "Estoque insuficiente no lote " + item.lot.lot + ".", Toast.LENGTH_LONG).show();
                    return;
                }
                item.lot.qty -= item.quantity;
                item.collected = true;
                collectedItems[0]++;
                collectedUnits[0] += item.quantity;
                saveProducts();

                collectButton.setText("✅ COLETADO — ESTOQUE: " + item.lot.qty + " un.");
                collectButton.setEnabled(false);
                nextButton.setEnabled(true);
                instruction.setText(current[0] == totalItems - 1
                        ? "🎉 Último item separado. Toque em PEDIDO OK para finalizar."
                        : "✅ Item separado. Toque em PRÓXIMO para continuar a coleta.");

                int percent = (int) Math.round((collectedItems[0] * 100.0) / totalItems);
                progressTitle.setText("Coleta " + collectedItems[0] + " de " + totalItems);
                progressNumbers.setText(percent + "% • " + collectedUnits[0] + " de " + totalUnitsFinal + " unidades");
                progressBar.setProgress(collectedItems[0] * 100);
                if (collectedItems[0] == totalItems) {
                    nextButton.setEnabled(false);
                    finalize.setEnabled(true);
                }
            });

            nextButton.setOnClickListener(v -> {
                if (current[0] >= totalItems - 1) return;
                current[0]++;
                refresh.run();
            });

            finalize.setOnClickListener(v -> {
                if (collectedItems[0] != totalItems) {
                    Toast.makeText(this, "Ainda existem itens pendentes.", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveCollectionBatch(items);
                showCollectionFinished(totalItems, totalUnitsFinal);
            });

            refresh.run();
        }
    }

    private void showCollectionFinished(int totalItems, int totalUnits) {
        base("Pedido finalizado", "Coleta concluída e registrada no histórico.");

        LinearLayout successCard = new LinearLayout(this);
        successCard.setOrientation(LinearLayout.VERTICAL);
        successCard.setGravity(Gravity.CENTER);
        successCard.setPadding(dp(20), dp(24), dp(20), dp(24));
        successCard.setBackground(background(Color.WHITE, 20));

        TextView icon = title("✅", 42);
        icon.setGravity(Gravity.CENTER);
        successCard.addView(icon);

        TextView done = title("Pedido OK!", 24);
        done.setGravity(Gravity.CENTER);
        successCard.addView(done, marginParams(0, 6, 0, 4));

        TextView summary = label(totalItems + (totalItems == 1 ? " item" : " itens")
                + " • " + totalUnits + (totalUnits == 1 ? " unidade" : " unidades")
                + " coletadas", 15, GRAY);
        summary.setGravity(Gravity.CENTER);
        successCard.addView(summary);

        TextView historyNote = label("A coleta já está salva no Histórico e o estoque foi atualizado.", 14, DARK);
        historyNote.setGravity(Gravity.CENTER);
        successCard.addView(historyNote, marginParams(0, 12, 0, 0));
        box.addView(successCard, marginParams(0, 4, 0, 16));

        Button newCollection = actionButton("📷 NOVA COLETA");
        newCollection.setTextSize(17);
        newCollection.setMinHeight(dp(58));
        newCollection.setOnClickListener(v -> startPhotoCollection());
        box.addView(newCollection, marginParams(0, 0, 0, 10));

        Button history = actionButton("🕘 VER HISTÓRICO");
        history.setTextSize(17);
        history.setMinHeight(dp(58));
        history.setOnClickListener(v -> collectionHistory());
        box.addView(history, marginParams(0, 0, 0, 10));

        Button homeButton = actionButton("🏠 VOLTAR AO INÍCIO");
        homeButton.setTextSize(17);
        homeButton.setMinHeight(dp(58));
        homeButton.setOnClickListener(v -> home());
        box.addView(homeButton, marginParams(0, 0, 0, 8));
    }

    private ArrayList<PickItem> buildPickItems(String text) {
        ArrayList<PickItem> result = new ArrayList<>();
        String[] lines = text.split("\\r?\\n");
        for (Product product : products) {
            int bestLine = -1;
            int bestScore = 0;
            String productName = normalize(product.name);
            String productCode = normalize(product.code);
            for (int i = 0; i < lines.length; i++) {
                String line = normalize(lines[i]);
                int score = 0;
                if (!productName.isEmpty() && line.contains(productName)) score += 5;
                if (!productCode.isEmpty() && line.contains(productCode)) score += 4;
                String[] words = productName.split(" ");
                int matched = 0;
                for (String word : words) {
                    if (word.length() >= 3 && line.contains(word)) matched++;
                }
                if (matched >= Math.max(1, words.length / 2)) score += 2;
                if (score > bestScore) {
                    bestScore = score;
                    bestLine = i;
                }
            }
            if (bestLine >= 0 && bestScore >= 2 && !product.lots.isEmpty()) {
                int quantity = findQuantity(lines, bestLine);
                if (quantity <= 0) quantity = product.lots.get(0).qty;
                addPickItemsForProduct(result, product, quantity);
            }
        }
        Collections.sort(result, (a, b) -> comparePositions(a.position, b.position));
        return result;
    }

    private void addPickItemsForProduct(ArrayList<PickItem> result, Product product, int requested) {
        int remaining = requested;
        ArrayList<Lot> lots = new ArrayList<>(product.lots);
        Collections.sort(lots, (a, b) -> a.pos.compareToIgnoreCase(b.pos));
        for (Lot lot : lots) {
            if (remaining <= 0) break;
            int available = Math.max(0, lot.qty);
            if (available == 0) continue;
            int take = Math.min(remaining, available);
            result.add(new PickItem(product, lot, take));
            remaining -= take;
        }
    }

    private int findQuantity(String[] lines, int productLine) {
        for (int i = productLine; i <= Math.min(lines.length - 1, productLine + 2); i++) {
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(?:x|qtd|qtde|quantidade|un|und)?\\s*[:=]?\\s*(\\d{1,5})\\b", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(lines[i]);
            if (matcher.find()) {
                try {
                    int value = Integer.parseInt(matcher.group(1));
                    if (value > 0) return value;
                } catch (Exception ignored) { }
            }
        }
        return 0;
    }

    private String normalize(String value) {
        if (value == null) return "";
        String normalized = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
        return normalized;
    }

    private static class PickItem {
        Product product;
        Lot lot;
        int quantity;
        String position;
        boolean collected;

        PickItem(Product product, Lot lot, int quantity) {
            this.product = product;
            this.lot = lot;
            this.quantity = quantity;
            this.position = lot.pos;
        }
    }

    private void showSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            resultCount.setText("Digite para localizar");
            return;
        }

        int found = 0;
        for (Product product : products) {
            if (product.matches(q)) {
                results.addView(productCard(product), marginParams(0, 0, 0, 10));
                found++;
            }
        }

        resultCount.setText(found == 0
                ? "Nenhum produto encontrado"
                : found + (found == 1 ? " produto encontrado" : " produtos encontrados"));

        if (found == 0) {
            TextView empty = label("Não encontramos esse produto.", 14, GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(24), dp(12), dp(24));
            results.addView(empty);
        }
    }

    private View productCard(final Product product) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(background(Color.WHITE, 16));

        card.addView(title(product.name, 18));
        card.addView(label("Código: " + product.code, 13, GRAY));
        card.addView(label("🏷️ " + product.lots.size() + " lote(s)", 14, BLUE));

        for (Lot lot : product.lots) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setBackground(background(Color.rgb(239, 246, 255), 10));
            row.addView(title("Lote: " + lot.lot, 15));
            row.addView(label("📍 " + lot.pos + "    📦 " + lot.qty + " un.", 14, DARK));
            card.addView(row, marginParams(0, 6, 0, 0));
        }

        card.setOnClickListener(v -> productDetails(product));
        return card;
    }

    private void productDetails(final Product product) {
        base("Produto", "Gerencie os lotes, posições e quantidades");
        box.addView(title(product.name, 21));
        box.addView(label("Código: " + product.code, 14, GRAY), marginParams(0, 2, 0, 12));
        box.addView(sectionTitle("Lotes"));

        if (product.lots.isEmpty()) {
            box.addView(label("Nenhum lote cadastrado.", 14, GRAY), marginParams(0, 4, 0, 10));
        } else {
            for (Lot lot : new ArrayList<>(product.lots)) {
                addLotRow(product, lot);
            }
        }

        Button addLot = actionButton("➕ Adicionar lote");
        addLot.setOnClickListener(v -> addLotDialog(product));
        box.addView(addLot, marginParams(0, 10, 0, 8));

        Button edit = actionButton("✏️ Editar produto");
        edit.setOnClickListener(v -> editProductDialog(product));
        box.addView(edit, marginParams(0, 0, 0, 8));

        Button registerAnother = actionButton("➕ Cadastrar outro produto");
        registerAnother.setOnClickListener(v -> newProduct());
        box.addView(registerAnother, marginParams(0, 0, 0, 8));

        Button delete = dangerButton("🗑️ Excluir produto");
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Excluir produto?")
                .setMessage("Isso removerá o produto e todos os seus lotes.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> {
                    products.remove(product);
                    saveProducts();
                    home();
                })
                .show());
        box.addView(delete, marginParams(0, 0, 0, 8));

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private void addLotRow(final Product product, final Lot lot) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(background(Color.WHITE, 12));
        row.addView(title("🏷️ Lote: " + lot.lot, 16));
        row.addView(label("📍 Posição: " + lot.pos + "   •   📦 Quantidade: " + lot.qty, 14, DARK));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button edit = actionButton("✏️ Editar lote");
        edit.setOnClickListener(v -> editLotDialog(product, lot));
        Button delete = dangerButton("Excluir");
        delete.setOnClickListener(v -> {
            product.lots.remove(lot);
            saveProducts();
            productDetails(product);
        });

        buttons.addView(edit, new LinearLayout.LayoutParams(0, dp(52), 1));
        buttons.addView(delete, new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(buttons, marginParams(0, 8, 0, 0));
        box.addView(row, marginParams(0, 0, 0, 8));
    }

    private void newProduct() {
        final EditText name = field("Nome do produto");
        final EditText code = field("Código/SKU (opcional)");

        LinearLayout content = dialogContent();
        content.addView(name);
        content.addView(code, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle("Cadastrar produto")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar", (dialog, which) -> {
                    String productName = name.getText().toString().trim();
                    if (productName.isEmpty()) {
                        Toast.makeText(this, "Informe o nome do produto.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Product product = new Product(code.getText().toString().trim(), productName);
                    products.add(product);
                    sortProducts();
                    saveProducts();
                    addLotDialog(product);
                })
                .show();
    }

    private LinearLayout dialogContent() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(8), dp(4), dp(8), dp(4));
        return layout;
    }

    private EditText field(String hint) {
        EditText editText = new EditText(this);
        editText.setHint(hint);
        editText.setSingleLine(true);
        editText.setTextSize(16);
        return editText;
    }

    private void editProductDialog(final Product product) {
        LinearLayout content = dialogContent();
        EditText name = field("Nome do produto");
        EditText code = field("Código/SKU");
        name.setText(product.name);
        code.setText(product.code);
        content.addView(name);
        content.addView(code, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle("Editar produto")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String newName = name.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "Informe o nome do produto.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    product.name = newName;
                    product.code = code.getText().toString().trim();
                    sortProducts();
                    saveProducts();
                    productDetails(product);
                })
                .show();
    }

    private void addLotDialog(Product product) {
        lotDialog(product, null);
    }

    private void editLotDialog(Product product, Lot lot) {
        lotDialog(product, lot);
    }

    private void lotDialog(final Product product, final Lot oldLot) {
        LinearLayout content = dialogContent();
        EditText lot = field("Lote");
        EditText position = field("Posição no estoque");
        EditText quantity = field("Quantidade");
        quantity.setInputType(InputType.TYPE_CLASS_NUMBER);

        if (oldLot != null) {
            lot.setText(oldLot.lot);
            position.setText(oldLot.pos);
            quantity.setText(String.valueOf(oldLot.qty));
        }

        content.addView(lot);
        content.addView(position, marginParams(0, 8, 0, 0));
        content.addView(quantity, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle(oldLot == null ? "Adicionar lote" : "Editar lote")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String lotValue = lot.getText().toString().trim();
                    String positionValue = position.getText().toString().trim();
                    String quantityValue = quantity.getText().toString().trim();

                    if (lotValue.isEmpty() || positionValue.isEmpty() || quantityValue.isEmpty()) {
                        Toast.makeText(this, "Preencha lote, posição e quantidade.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        int quantityNumber = Integer.parseInt(quantityValue);
                        if (quantityNumber < 0) {
                            throw new NumberFormatException();
                        }

                        if (oldLot == null) {
                            product.lots.add(new Lot(lotValue, positionValue, quantityNumber));
                        } else {
                            oldLot.lot = lotValue;
                            oldLot.pos = positionValue;
                            oldLot.qty = quantityNumber;
                        }

                        saveProducts();
                        productDetails(product);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "A quantidade deve ser um número válido.", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private TextView sectionTitle(String text) {
        TextView view = title(text, 18);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        return view;
    }

    private void saveCollectionBatch(ArrayList<PickItem> items) {
        try {
            JSONArray history = new JSONArray(prefs.getString("collection_history", "[]"));
            JSONObject batch = new JSONObject();
            batch.put("date", new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ROOT).format(new Date()));
            batch.put("undone", false);
            JSONArray batchItems = new JSONArray();
            for (PickItem item : items) {
                JSONObject entry = new JSONObject();
                entry.put("code", item.product.code);
                entry.put("product", item.product.name);
                entry.put("lot", item.lot.lot);
                entry.put("pos", item.lot.pos);
                entry.put("qty", item.quantity);
                batchItems.put(entry);
            }
            batch.put("items", batchItems);
            history.put(batch);
            prefs.edit().putString("collection_history", history.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void collectionHistory() {
        base("Histórico de coletas", "Pedidos finalizados e baixas realizadas");
        try {
            JSONArray history = new JSONArray(prefs.getString("collection_history", "[]"));
            if (history.length() == 0) {
                box.addView(label("Nenhuma coleta finalizada ainda.", 15, GRAY), marginParams(0, 8, 0, 12));
            } else {
                for (int i = history.length() - 1; i >= 0; i--) {
                    final int index = i;
                    JSONObject batch = history.getJSONObject(i);
                    boolean undone = batch.optBoolean("undone", false);
                    JSONArray batchItems = batch.optJSONArray("items");

                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(16), dp(14), dp(16), dp(14));
                    card.setBackground(background(Color.WHITE, 16));

                    String status = undone ? "↩️ DESFEITO" : "✅ FINALIZADO";
                    TextView header = title(status + " • " + batch.optString("date", ""), 16);
                    header.setTextColor(undone ? GRAY : GREEN);
                    card.addView(header);

                    int total = 0;
                    if (batchItems != null) {
                        for (int j = 0; j < batchItems.length(); j++) {
                            JSONObject item = batchItems.getJSONObject(j);
                            total += item.optInt("qty", 0);
                            card.addView(label("📦 " + item.optString("product", "")
                                    + "\n🏷️ Lote: " + item.optString("lot", "")
                                    + "\n📍 Posição: " + item.optString("pos", "")
                                    + "\n🔢 Quantidade: " + item.optInt("qty", 0), 14, DARK),
                                    marginParams(0, 8, 0, 0));
                        }
                    }
                    card.addView(label("Total: " + total + " unidades", 13, GRAY), marginParams(0, 8, 0, 0));

                    if (!undone) {
                        Button undo = dangerButton("↩️ DESFAZER PEDIDO");
                        undo.setOnClickListener(v -> undoCollection(index));
                        card.addView(undo, marginParams(0, 10, 0, 0));
                    }
                    box.addView(card, marginParams(0, 0, 0, 10));
                }
            }
        } catch (Exception e) {
            box.addView(label("Não foi possível carregar o histórico.", 15, RED));
        }

        Button back = actionButton("⬅ Voltar para início");
        back.setOnClickListener(v -> home());
        box.addView(back, marginParams(0, 4, 0, 8));
    }

    private void undoCollection(int historyIndex) {
        try {
            JSONArray history = new JSONArray(prefs.getString("collection_history", "[]"));
            if (historyIndex < 0 || historyIndex >= history.length()) return;
            JSONObject batch = history.getJSONObject(historyIndex);
            if (batch.optBoolean("undone", false)) {
                Toast.makeText(this, "Esta coleta já foi desfeita.", Toast.LENGTH_SHORT).show();
                return;
            }

            JSONArray batchItems = batch.optJSONArray("items");
            if (batchItems != null) {
                for (int i = 0; i < batchItems.length(); i++) {
                    JSONObject entry = batchItems.getJSONObject(i);
                    String code = entry.optString("code", "");
                    String lotName = entry.optString("lot", "");
                    String pos = entry.optString("pos", "");
                    int qty = entry.optInt("qty", 0);

                    for (Product product : products) {
                        if (!product.code.equals(code)) continue;
                        for (Lot lot : product.lots) {
                            if (lot.lot.equals(lotName) && lot.pos.equals(pos)) {
                                lot.qty += qty;
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            batch.put("undone", true);
            prefs.edit().putString("collection_history", history.toString()).apply();
            saveProducts();
            Toast.makeText(this, "Pedido desfeito e estoque restaurado.", Toast.LENGTH_LONG).show();
            collectionHistory();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível desfazer esta coleta.", Toast.LENGTH_LONG).show();
        }
    }

    private void catalog() {
        base("Produtos cadastrados", "Produtos e todos os seus lotes");

        Button register = actionButton("➕ Cadastrar novo produto");
        register.setOnClickListener(v -> newProduct());
        box.addView(register, marginParams(0, 0, 0, 12));

        if (products.isEmpty()) {
            box.addView(label("Nenhum produto cadastrado.", 14, GRAY));
        } else {
            for (Product product : products) {
                box.addView(productCard(product), marginParams(0, 0, 0, 10));
            }
        }

        Button back = actionButton("⬅ Voltar para busca");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private void picking() {
        base("Picking • NF-e 000123", "Separe os produtos seguindo as posições");
        final int[] separated = {0};
        final ArrayList<Product> pickingProducts = new ArrayList<>();
        for (Product product : products) {
            if (!product.lots.isEmpty()) {
                pickingProducts.add(product);
            }
        }

        final TextView progress = title("Progresso: 0/" + pickingProducts.size() + " produtos", 18);
        box.addView(progress, marginParams(0, 0, 0, 10));

        for (Product product : pickingProducts) {
            Lot lot = product.lots.get(0);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(background(Color.WHITE, 14));
            card.addView(title(product.name + " • " + lot.qty + " un.", 18));
            card.addView(label("🏷️ Lote: " + lot.lot + "\n📍 Posição: " + lot.pos + "\nCódigo: " + product.code, 15, DARK));

            Button done = actionButton("Marcar como separado");
            done.setOnClickListener(v -> {
                if (done.isEnabled()) {
                    separated[0]++;
                    done.setText("✅ Separado");
                    done.setEnabled(false);
                    progress.setText("Progresso: " + separated[0] + "/" + pickingProducts.size() + " produtos");
                }
            });
            card.addView(done, marginParams(0, 8, 0, 0));
            box.addView(card, marginParams(0, 0, 0, 10));
        }

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private static class Lot {
        String lot;
        String pos;
        int qty;

        Lot(String lot, String pos, int qty) {
            this.lot = lot;
            this.pos = pos;
            this.qty = qty;
        }
    }

    private static class Product {
        String code;
        String name;
        ArrayList<Lot> lots = new ArrayList<>();

        Product(String code, String name) {
            this.code = code;
            this.name = name;
        }

        boolean matches(String query) {
            if (name.toLowerCase(Locale.ROOT).contains(query)) {
                return true;
            }
            if (code.toLowerCase(Locale.ROOT).contains(query)) {
                return true;
            }
            for (Lot lot : lots) {
                if (lot.lot.toLowerCase(Locale.ROOT).contains(query)
                        || lot.pos.toLowerCase(Locale.ROOT).contains(query)) {
                    return true;
                }
            }
            return false;
        }
    }
}
