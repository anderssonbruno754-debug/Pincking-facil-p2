# PickFácil SIM.KO v2.0

Versão visual consolidada do aplicativo de gestão de estoque e coleta.

## Atualizações desta versão
- Remove a barra de navegação fixa inferior para deixar a interface mais limpa.
- Mantém a navegação entre páginas por gesto de deslize horizontal.
- Paleta visual alinhada ao ícone: azul, azul-escuro, amarelo e branco.
- Identidade da empresa **SIM.KO** no aplicativo.
- Ícone do aplicativo atualizado.
- Versão Android 2.0 (versionCode 11).

## Recursos mantidos
- Cadastro de produtos.
- Vários lotes por produto, com posição e quantidade.
- Pesquisa de produtos.
- Leitura de nota por foto.
- Lista inteligente de coleta.
- Barra de progresso, posição atual e botão Próximo.
- Baixa automática do estoque ao coletar.
- Finalização do pedido e histórico de coletas.
- Navegação por gesto.

## Gerar APK
No GitHub Actions, execute o workflow **Gerar APK Pick Fácil** e baixe o artefato gerado.

> A lista definitiva de produtos será incorporada quando for enviada pelo usuário.
