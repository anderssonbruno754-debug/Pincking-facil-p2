# PickFácil — Coleta Profissional Corrigida

Versão 1.6.

Correções desta versão:
- Corrigida a navegação para Histórico de coletas.
- Implementado o salvamento do pedido finalizado no histórico ao tocar em PEDIDO OK.
- Implementado DESFAZER PEDIDO, restaurando as quantidades baixadas no estoque.
- Corrigido o uso dos parâmetros de margem do layout na tela inicial.
- Mantida a coleta profissional com barra de progresso, posição atual em destaque e botão PRÓXIMO.
- Mantidos cadastro de produtos, múltiplos lotes, posições, leitura de nota por foto e baixa automática.

## Gerar APK
Use GitHub Actions e execute o workflow **Gerar APK Pick Fácil**. O APK será publicado como artefato.


## Melhoria 8 — Finalização e navegação da coleta
- Removidos da tela de coleta os botões de texto reconhecido e fotografar outra nota.
- Após finalizar um pedido, a coleta sai da tela de picking e abre uma tela de confirmação.
- A confirmação oferece Nova coleta, Ver histórico e Voltar ao início.
- A coleta continua sendo registrada no histórico e o estoque continua sendo baixado automaticamente.


## Melhoria 9 — Cadastro contínuo de produtos
- Botão "Cadastrar outro produto" na tela do produto.
- Botão "Cadastrar novo produto" na tela de produtos cadastrados.
- O usuário não precisa voltar à tela inicial para iniciar outro cadastro.


## Melhoria 10 — Navegação por gestos
- Navegação entre Início, Coletar, Estoque e Histórico por deslize horizontal.
- A barra inferior continua disponível como alternativa.

## Identidade da empresa
- Nome da empresa exibido no cabeçalho das telas: SIM.KO
