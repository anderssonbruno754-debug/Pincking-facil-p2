# PickFácil — Visual Profissional

Versão 1.5 baseada na versão funcional anterior.

## Melhorias
- Nova tela inicial em formato de painel.
- Cartão de destaque para iniciar coleta por foto.
- Atalhos em grade para Ler nota, Novo produto, Estoque e Histórico.
- Indicadores de produtos, lotes e unidades.
- Barra de navegação inferior com abas Início, Coletar, Estoque e Histórico.
- Mantidas as funções anteriores de cadastro, múltiplos lotes, posições, quantidades, leitura por foto, lista inteligente, Pedido OK, baixa automática e histórico.

## Build
O workflow em `.github/workflows/build-apk.yml` gera o APK debug pelo GitHub Actions.
