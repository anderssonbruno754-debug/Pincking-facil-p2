package com.pickfacil.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout box;
    EditText searchInput;
    TextView resultCount;
    final ArrayList<Product> products = new ArrayList<>();
    int separated = 0;

    final int BLUE = Color.rgb(21, 101, 192);
    final int DARK = Color.rgb(31, 41, 55);
    final int GRAY = Color.rgb(107, 114, 128);
    final int LIGHT = Color.rgb(247, 249, 252);
    final int GREEN = Color.rgb(22, 163, 74);

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BLUE);
        loadProducts();
        home();
    }

    void loadProducts() {
        products.clear();
        products.add(new Product("789100000001", "Arroz 5 kg", 2, "A-01-03"));
        products.add(new Product("789100000002", "Feijão 1 kg", 4, "A-02-01"));
        products.add(new Product("789100000004", "Açúcar 1 kg", 3, "B-01-02"));
        products.add(new Product("789100000003", "Café 500 g", 1, "B-03-05"));
        Collections.sort(products, (a, b) -> a.pos.compareToIgnoreCase(b.pos));
    }

    int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    TextView label(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(4), dp(4), dp(4), dp(4));
        return v;
    }

    TextView title(String s, float size) {
        TextView v = label(s, size, DARK);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    Button actionButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(bg(BLUE, 12));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        return b;
    }

    void base(String screenTitle, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(box);
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(12));
        TextView t = title("📦 " + screenTitle, 25);
        header.addView(t);
        header.addView(label(subtitle, 13, GRAY));
        box.addView(header);
    }

    void home() {
        base("PickFácil", "Localize produtos rapidamente no estoque");

        LinearLayout searchCard = new LinearLayout(this);
        searchCard.setOrientation(LinearLayout.VERTICAL);
        searchCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        searchCard.setBackground(bg(Color.WHITE, 16));
        box.addView(searchCard, marginParams(0, 4, 0, 14));

        searchCard.addView(title("🔎 Buscar produto", 18));
        searchInput = new EditText(this);
        searchInput.setHint("Nome do produto ou código de barras");
        searchInput.setTextSize(16);
        searchInput.setSingleLine(true);
        searchInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchInput.setBackground(bg(LIGHT, 12));
        searchCard.addView(searchInput, marginParams(0, 8, 0, 0));

        resultCount = label("Digite para localizar", 13, GRAY);
        searchCard.addView(resultCount, marginParams(0, 8, 0, 0));

        LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        box.addView(results, marginParams(0, 0, 0, 14));

        searchInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) {
                showSearchResults(results, s.toString());
            }
            public void afterTextChanged(Editable e) {}
        });

        box.addView(sectionTitle("Acesso rápido"));

        Button pick = actionButton("📍 Abrir picking de exemplo");
        pick.setOnClickListener(v -> picking());
        box.addView(pick, marginParams(0, 4, 0, 8));

        Button cat = actionButton("🗃️ Ver todos os produtos");
        cat.setOnClickListener(v -> catalog());
        box.addView(cat, marginParams(0, 0, 0, 12));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), dp(12), dp(14), dp(12));
        info.setBackground(bg(Color.rgb(239, 246, 255), 14));
        info.addView(title("Como funciona", 16));
        info.addView(label("Digite parte do nome ou o código. O PickFácil mostra automaticamente a posição e a quantidade disponível.", 14, DARK));
        box.addView(info);
    }

    void showSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            resultCount.setText("Digite para localizar");
            return;
        }

        int found = 0;
        for (Product p : products) {
            if (p.name.toLowerCase(Locale.ROOT).contains(q) || p.code.contains(q) || p.pos.toLowerCase(Locale.ROOT).contains(q)) {
                results.addView(productCard(p));
                found++;
            }
        }
        resultCount.setText(found == 0 ? "Nenhum produto encontrado" : found + (found == 1 ? " produto encontrado" : " produtos encontrados"));
        if (found == 0) {
            TextView empty = label("Não encontramos esse produto. Confira o nome ou o código.", 14, GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(24), dp(12), dp(24));
            results.addView(empty);
        }
    }

    View productCard(Product p) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(bg(Color.WHITE, 16));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setWeightSum(1);
        TextView name = title(p.name, 18);
        top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView qty = title("" + p.qty + " un.", 18);
        qty.setTextColor(GREEN);
        qty.setGravity(Gravity.RIGHT);
        top.addView(qty, new LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(top);

        LinearLayout posBox = new LinearLayout(this);
        posBox.setGravity(Gravity.CENTER_VERTICAL);
        posBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        posBox.setBackground(bg(Color.rgb(239, 246, 255), 10));
        TextView pos = title("📍 " + p.pos, 17);
        pos.setTextColor(BLUE);
        posBox.addView(pos, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        posBox.addView(label("posição", 12, GRAY));
        card.addView(posBox, marginParams(0, 10, 0, 8));

        card.addView(label("Código: " + p.code, 13, GRAY));
        card.setOnClickListener(v -> productDetails(p));
        return card;
    }

    void productDetails(Product p) {
        base("Produto", "Informações para o picking");
        box.addView(productCard(p), marginParams(0, 6, 0, 14));
        Button back = actionButton("⬅ Voltar para busca");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    TextView sectionTitle(String s) {
        TextView v = title(s, 18);
        v.setPadding(dp(4), dp(8), dp(4), dp(8));
        return v;
    }

    void note() {
        base("Ler nota fiscal", "Entrada da nota fiscal no picking");
        box.addView(label("📄 Leitura simulada da NF-e 000123\n4 itens encontrados • 10 unidades", 17, DARK));
        Button use = actionButton("✅ Usar esta nota no picking");
        use.setOnClickListener(v -> picking());
        box.addView(use, marginParams(0, 14, 0, 8));
        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    void picking() {
        base("Picking • NF-e 000123", "Separe os produtos seguindo as posições");
        TextView progress = title("Progresso: " + separated + "/" + products.size() + " produtos", 18);
        box.addView(progress, marginParams(0, 0, 0, 10));
        for (Product p : products) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(bg(Color.WHITE, 14));
            card.addView(title(p.name + " • " + p.qty + " un.", 18));
            card.addView(label("📍 Posição: " + p.pos + "\nCódigo: " + p.code, 15, DARK));
            Button ok = actionButton(p.done ? "✅ Separado" : "Marcar como separado");
            ok.setEnabled(!p.done);
            ok.setOnClickListener(v -> {
                if (!p.done) {
                    p.done = true;
                    separated++;
                    ok.setText("✅ Separado");
                    ok.setEnabled(false);
                    progress.setText("Progresso: " + separated + "/" + products.size() + " produtos");
                }
            });
            card.addView(ok, marginParams(0, 8, 0, 0));
            box.addView(card, marginParams(0, 0, 0, 10));
        }
        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back, marginParams(0, 6, 0, 0));
    }

    void catalog() {
        base("Produtos e posições", "Todos os produtos cadastrados");
        for (Product p : products) {
            box.addView(productCard(p), marginParams(0, 0, 0, 10));
        }
        Button back = actionButton("⬅ Voltar para busca");
        back.setOnClickListener(v -> home());
        box.addView(back, marginParams(0, 4, 0, 0));
    }

    LinearLayout.LayoutParams marginParams(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        return lp;
    }

    static class Product {
        String code, name, pos;
        int qty;
        boolean done;
        Product(String c, String n, int q, String p) {
            code = c;
            name = n;
            qty = q;
            pos = p;
        }
    }
}
