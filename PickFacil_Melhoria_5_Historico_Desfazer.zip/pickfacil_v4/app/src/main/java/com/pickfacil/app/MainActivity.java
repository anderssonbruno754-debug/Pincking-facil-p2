package com.pickfacil.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 7001;
    private Uri pendingPhotoUri;

    private LinearLayout box;
    private EditText searchInput;
    private TextView resultCount;
    private final ArrayList<Product> products = new ArrayList<>();
    private SharedPreferences prefs;

    private final int BLUE = Color.rgb(21, 101, 192);
    private final int DARK = Color.rgb(31, 41, 55);
    private final int GRAY = Color.rgb(107, 114, 128);
    private final int LIGHT = Color.rgb(247, 249, 252);
    private final int GREEN = Color.rgb(22, 163, 74);
    private final int RED = Color.rgb(220, 38, 38);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLUE);
        prefs = getSharedPreferences("pickfacil", MODE_PRIVATE);
        loadProducts();
        home();
    }

    private void loadProducts() {
        products.clear();
        String raw = prefs.getString("products", "");
        try {
            if (raw.isEmpty()) {
                products.add(sampleProduct("789100000001", "Arroz 5 kg", "A-01-03", 2));
                products.add(sampleProduct("789100000002", "Feijão 1 kg", "A-02-01", 4));
                products.add(sampleProduct("789100000004", "Açúcar 1 kg", "B-01-02", 3));
                products.add(sampleProduct("789100000003", "Café 500 g", "B-03-05", 1));
                saveProducts();
            } else {
                JSONArray array = new JSONArray(raw);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    Product product = new Product(
                            object.optString("code"),
                            object.optString("name")
                    );
                    JSONArray lots = object.optJSONArray("lots");
                    if (lots != null) {
                        for (int j = 0; j < lots.length(); j++) {
                            JSONObject lotObject = lots.getJSONObject(j);
                            product.lots.add(new Lot(
                                    lotObject.optString("lot"),
                                    lotObject.optString("pos"),
                                    lotObject.optInt("qty", 0)
                            ));
                        }
                    }
                    products.add(product);
                }
            }
        } catch (Exception ignored) {
            products.clear();
            products.add(sampleProduct("789100000001", "Arroz 5 kg", "A-01-03", 2));
            products.add(sampleProduct("789100000002", "Feijão 1 kg", "A-02-01", 4));
            saveProducts();
        }
        sortProducts();
    }

    private Product sampleProduct(String code, String name, String position, int quantity) {
        Product product = new Product(code, name);
        product.lots.add(new Lot("Lote exemplo", position, quantity));
        return product;
    }

    private void sortProducts() {
        Collections.sort(products, (a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    private void saveProducts() {
        try {
            JSONArray array = new JSONArray();
            for (Product product : products) {
                JSONObject object = new JSONObject();
                object.put("code", product.code);
                object.put("name", product.name);
                JSONArray lots = new JSONArray();
                for (Lot lot : product.lots) {
                    JSONObject lotObject = new JSONObject();
                    lotObject.put("lot", lot.lot);
                    lotObject.put("pos", lot.pos);
                    lotObject.put("qty", lot.qty);
                    lots.put(lotObject);
                }
                object.put("lots", lots);
                array.put(object);
            }
            prefs.edit().putString("products", array.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private TextView label(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(dp(4), dp(4), dp(4), dp(4));
        return view;
    }

    private TextView title(String text, float size) {
        TextView view = label(text, size, DARK);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackground(background(BLUE, 12));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        return button;
    }

    private Button dangerButton(String text) {
        Button button = actionButton(text);
        button.setBackground(background(RED, 12));
        return button;
    }

    private void base(String screenTitle, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(box);
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(12));
        header.addView(title("📦 " + screenTitle, 25));
        header.addView(label(subtitle, 13, GRAY));
        box.addView(header);
    }

    private void home() {
        base("PickFácil", "Localize produtos rapidamente no estoque");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(background(Color.WHITE, 16));
        box.addView(card, marginParams(0, 4, 0, 14));

        card.addView(title("🔎 Buscar produto", 18));
        searchInput = new EditText(this);
        searchInput.setHint("Nome, código, lote ou posição");
        searchInput.setTextSize(16);
        searchInput.setSingleLine(true);
        searchInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchInput.setBackground(background(LIGHT, 12));
        card.addView(searchInput, marginParams(0, 8, 0, 0));

        resultCount = label("Digite para localizar", 13, GRAY);
        card.addView(resultCount, marginParams(0, 8, 0, 0));

        final LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        box.addView(results, marginParams(0, 0, 0, 14));

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                showSearchResults(results, s.toString());
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        box.addView(sectionTitle("Acesso rápido"));

        Button photoPicking = actionButton("📷 Coletar por foto da nota");
        photoPicking.setOnClickListener(v -> startPhotoCollection());
        box.addView(photoPicking, marginParams(0, 4, 0, 8));

        Button register = actionButton("➕ Cadastrar produto");
        register.setOnClickListener(v -> newProduct());
        box.addView(register, marginParams(0, 0, 0, 8));

        Button catalog = actionButton("🗃️ Ver produtos cadastrados");
        catalog.setOnClickListener(v -> catalog());
        box.addView(catalog, marginParams(0, 0, 0, 8));

        Button history = actionButton("🕘 Histórico de coletas");
        history.setOnClickListener(v -> collectionHistory());
        box.addView(history, marginParams(0, 0, 0, 8));

        Button picking = actionButton("📍 Abrir picking de exemplo");
        picking.setOnClickListener(v -> picking());
        box.addView(picking, marginParams(0, 0, 0, 12));
    }

    private void startPhotoCollection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
            return;
        }
        openCamera();
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, "Câmera não encontrada neste aparelho.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "pickfacil_nota_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PickFacil");
            pendingPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) {
                Toast.makeText(this, "Não foi possível preparar a foto.", Toast.LENGTH_SHORT).show();
                return;
            }
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
        }

        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Precisamos da câmera para fotografar a nota.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAMERA || resultCode != RESULT_OK) {
            return;
        }

        if (pendingPhotoUri != null) {
            Uri uri = pendingPhotoUri;
            pendingPhotoUri = null;
            processPhoto(uri);
            return;
        }

        if (data != null && data.getExtras() != null) {
            Object value = data.getExtras().get("data");
            if (value instanceof Bitmap) {
                processBitmap((Bitmap) value);
            }
        }
    }

    private void processPhoto(Uri uri) {
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            recognizeText(image);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir a foto da nota.", Toast.LENGTH_LONG).show();
        }
    }

    private void processBitmap(Bitmap bitmap) {
        try {
            recognizeText(InputImage.fromBitmap(bitmap, 0));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível ler a foto.", Toast.LENGTH_LONG).show();
        }
    }

    private void recognizeText(InputImage image) {
        Toast.makeText(this, "Lendo a nota...", Toast.LENGTH_SHORT).show();
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText();
                    recognizer.close();
                    showPhotoResult(text);
                })
                .addOnFailureListener(error -> {
                    recognizer.close();
                    Toast.makeText(this, "Não consegui ler a nota. Tente uma foto mais nítida e bem iluminada.", Toast.LENGTH_LONG).show();
                });
    }

    private void showPhotoResult(String text) {
        if (text == null) text = "";
        String recognized = text.trim();
        ArrayList<PickItem> items = buildPickItems(recognized);
        showSmartPicking(items, recognized);
    }

    private void showSmartPicking(final ArrayList<PickItem> items, final String recognized) {
        base("Lista inteligente de coleta", items.isEmpty()
                ? "Nenhum produto cadastrado foi reconhecido automaticamente."
                : "Siga as posições na ordem e marque cada item após separar.");

        if (items.isEmpty()) {
            box.addView(label("Não foi possível montar a lista automaticamente.", 16, DARK), marginParams(0, 0, 0, 8));
        } else {
            int totalUnits = 0;
            for (PickItem item : items) totalUnits += item.quantity;

            final int[] collectedItems = {0};
            final int[] collectedUnits = {0};
            final int totalItems = items.size();
            final int totalUnitsFinal = totalUnits;

            TextView progress = title("0/" + totalItems + " itens • 0/" + totalUnitsFinal + " un.", 18);
            box.addView(progress, marginParams(0, 0, 0, 8));

            TextView instruction = label("📍 Ordem de coleta: posição → produto → lote → quantidade", 13, GRAY);
            box.addView(instruction, marginParams(0, 0, 0, 10));

            for (PickItem item : items) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14), dp(12), dp(14), dp(12));
                card.setBackground(background(Color.WHITE, 14));

                card.addView(title("📍 " + item.position, 20));
                card.addView(title(item.product.name, 17));
                card.addView(label("🏷️ Lote: " + item.lot.lot + "\n📦 Separar: " + item.quantity + " un.\n📊 Estoque antes: " + item.lot.qty + " un.", 14, DARK));

                Button done = actionButton("☐ Marcar como coletado");
                done.setOnClickListener(v -> {
                    if (!done.isEnabled() || item.collected) return;
                    if (item.lot.qty < item.quantity) {
                        Toast.makeText(this, "Estoque insuficiente no lote " + item.lot.lot + ".", Toast.LENGTH_LONG).show();
                        return;
                    }

                    item.lot.qty -= item.quantity;
                    item.collected = true;
                    collectedItems[0]++;
                    collectedUnits[0] += item.quantity;
                    saveProducts();
                    saveCollectionRecord(item);

                    done.setText("✅ Coletado — estoque: " + item.lot.qty + " un.");
                    done.setEnabled(false);
                    progress.setText(collectedItems[0] + "/" + totalItems + " itens • " + collectedUnits[0] + "/" + totalUnitsFinal + " un.");

                    if (collectedItems[0] == totalItems) {
                        instruction.setText("✅ Coleta concluída! O estoque dos lotes foi atualizado automaticamente.");
                        Toast.makeText(this, "Coleta concluída e estoque atualizado.", Toast.LENGTH_LONG).show();
                    }
                });
                card.addView(done, marginParams(0, 8, 0, 0));
                box.addView(card, marginParams(0, 0, 0, 10));
            }
        }

        Button rawButton = actionButton("👁️ Ver texto lido da foto");
        rawButton.setOnClickListener(v -> showRawTextDialog(recognized));
        box.addView(rawButton, marginParams(0, 4, 0, 8));

        Button retry = actionButton("📷 Fotografar outra nota");
        retry.setOnClickListener(v -> startPhotoCollection());
        box.addView(retry, marginParams(0, 0, 0, 8));

        Button catalogButton = actionButton("🗃️ Conferir estoque atualizado");
        catalogButton.setOnClickListener(v -> catalog());
        box.addView(catalogButton, marginParams(0, 0, 0, 8));

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private void saveCollectionRecord(PickItem item) {
        try {
            JSONArray history = new JSONArray(prefs.getString("collection_history", ""));
            JSONObject record = new JSONObject();
            record.put("date", new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ROOT).format(new Date()));
            record.put("timestamp", System.currentTimeMillis());
            record.put("code", item.product.code);
            record.put("product", item.product.name);
            record.put("lot", item.lot.lot);
            record.put("position", item.lot.pos);
            record.put("qty", item.quantity);
            record.put("undone", false);
            history.put(record);
            prefs.edit().putString("collection_history", history.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void collectionHistory() {
        base("Histórico de coletas", "Veja o que foi separado e desfaça uma baixa quando necessário.");
        JSONArray history = loadHistory();
        if (history.length() == 0) {
            box.addView(label("Nenhuma coleta registrada ainda.", 15, GRAY), marginParams(0, 4, 0, 12));
        } else {
            for (int i = history.length() - 1; i >= 0; i--) {
                try {
                    JSONObject record = history.getJSONObject(i);
                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(14), dp(12), dp(14), dp(12));
                    card.setBackground(background(Color.WHITE, 14));

                    String product = record.optString("product", "Produto");
                    String lot = record.optString("lot", "");
                    String position = record.optString("position", "");
                    int qty = record.optInt("qty", 0);
                    String date = record.optString("date", "");
                    boolean undone = record.optBoolean("undone", false);

                    card.addView(title(undone ? "↩️ " + product + " • desfeita" : "📦 " + product, 17));
                    card.addView(label("📅 " + date + "\n🏷️ Lote: " + lot + "\n📍 Posição: " + position + "\n📦 Quantidade: " + qty + " un.", 14, DARK));

                    if (!undone) {
                        Button undo = dangerButton("↩️ Desfazer esta baixa");
                        final int index = i;
                        undo.setOnClickListener(v -> confirmUndo(index));
                        card.addView(undo, marginParams(0, 8, 0, 0));
                    } else {
                        card.addView(label("Estoque devolvido ao lote.", 13, GREEN), marginParams(0, 6, 0, 0));
                    }
                    box.addView(card, marginParams(0, 0, 0, 10));
                } catch (Exception ignored) { }
            }
        }

        Button clear = dangerButton("🗑️ Limpar histórico");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Limpar histórico?")
                .setMessage("Isso apagará somente o histórico. As quantidades do estoque não serão alteradas.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpar", (d, w) -> {
                    prefs.edit().remove("collection_history").apply();
                    collectionHistory();
                }).show());
        box.addView(clear, marginParams(0, 4, 0, 8));

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private JSONArray loadHistory() {
        try {
            return new JSONArray(prefs.getString("collection_history", ""));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void confirmUndo(final int index) {
        new AlertDialog.Builder(this)
                .setTitle("Desfazer baixa?")
                .setMessage("A quantidade será devolvida ao mesmo lote e posição usados na coleta.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Desfazer", (dialog, which) -> undoCollection(index))
                .show();
    }

    private void undoCollection(int index) {
        try {
            JSONArray history = loadHistory();
            if (index < 0 || index >= history.length()) return;
            JSONObject record = history.getJSONObject(index);
            if (record.optBoolean("undone", false)) return;

            String code = record.optString("code", "");
            String lotName = record.optString("lot", "");
            String position = record.optString("position", "");
            int qty = record.optInt("qty", 0);
            boolean restored = false;

            for (Product product : products) {
                if (!product.code.equals(code)) continue;
                for (Lot lot : product.lots) {
                    if (lot.lot.equals(lotName) && lot.pos.equals(position)) {
                        lot.qty += qty;
                        restored = true;
                        break;
                    }
                }
                if (restored) break;
            }

            if (!restored) {
                Toast.makeText(this, "Não encontrei o lote original para devolver a quantidade.", Toast.LENGTH_LONG).show();
                return;
            }

            record.put("undone", true);
            history.put(index, record);
            prefs.edit().putString("collection_history", history.toString()).apply();
            saveProducts();
            Toast.makeText(this, "Baixa desfeita e estoque restaurado.", Toast.LENGTH_LONG).show();
            collectionHistory();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível desfazer esta baixa.", Toast.LENGTH_LONG).show();
        }
    }

    private void showRawTextDialog(String text) {
        TextView view = label(text.isEmpty() ? "Nenhum texto reconhecido." : text, 14, DARK);
        view.setPadding(dp(8), dp(8), dp(8), dp(8));
        new AlertDialog.Builder(this)
                .setTitle("Texto reconhecido")
                .setView(view)
                .setPositiveButton("Fechar", null)
                .show();
    }

    private ArrayList<PickItem> buildPickItems(String text) {
        ArrayList<PickItem> result = new ArrayList<>();
        String[] lines = text.split("\\r?\\n");
        for (Product product : products) {
            int bestLine = -1;
            int bestScore = 0;
            String productName = normalize(product.name);
            String productCode = normalize(product.code);
            for (int i = 0; i < lines.length; i++) {
                String line = normalize(lines[i]);
                int score = 0;
                if (!productName.isEmpty() && line.contains(productName)) score += 5;
                if (!productCode.isEmpty() && line.contains(productCode)) score += 4;
                String[] words = productName.split(" ");
                int matched = 0;
                for (String word : words) {
                    if (word.length() >= 3 && line.contains(word)) matched++;
                }
                if (matched >= Math.max(1, words.length / 2)) score += 2;
                if (score > bestScore) {
                    bestScore = score;
                    bestLine = i;
                }
            }
            if (bestLine >= 0 && bestScore >= 2 && !product.lots.isEmpty()) {
                int quantity = findQuantity(lines, bestLine);
                if (quantity <= 0) quantity = product.lots.get(0).qty;
                addPickItemsForProduct(result, product, quantity);
            }
        }
        Collections.sort(result, (a, b) -> a.position.compareToIgnoreCase(b.position));
        return result;
    }

    private void addPickItemsForProduct(ArrayList<PickItem> result, Product product, int requested) {
        int remaining = requested;
        ArrayList<Lot> lots = new ArrayList<>(product.lots);
        Collections.sort(lots, (a, b) -> a.pos.compareToIgnoreCase(b.pos));
        for (Lot lot : lots) {
            if (remaining <= 0) break;
            int available = Math.max(0, lot.qty);
            if (available == 0) continue;
            int take = Math.min(remaining, available);
            result.add(new PickItem(product, lot, take));
            remaining -= take;
        }
    }

    private int findQuantity(String[] lines, int productLine) {
        for (int i = productLine; i <= Math.min(lines.length - 1, productLine + 2); i++) {
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(?:x|qtd|qtde|quantidade|un|und)?\\s*[:=]?\\s*(\\d{1,5})\\b", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(lines[i]);
            if (matcher.find()) {
                try {
                    int value = Integer.parseInt(matcher.group(1));
                    if (value > 0) return value;
                } catch (Exception ignored) { }
            }
        }
        return 0;
    }

    private String normalize(String value) {
        if (value == null) return "";
        String normalized = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
        return normalized;
    }

    private static class PickItem {
        Product product;
        Lot lot;
        int quantity;
        String position;
        boolean collected;

        PickItem(Product product, Lot lot, int quantity) {
            this.product = product;
            this.lot = lot;
            this.quantity = quantity;
            this.position = lot.pos;
        }
    }

    private void showSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            resultCount.setText("Digite para localizar");
            return;
        }

        int found = 0;
        for (Product product : products) {
            if (product.matches(q)) {
                results.addView(productCard(product), marginParams(0, 0, 0, 10));
                found++;
            }
        }

        resultCount.setText(found == 0
                ? "Nenhum produto encontrado"
                : found + (found == 1 ? " produto encontrado" : " produtos encontrados"));

        if (found == 0) {
            TextView empty = label("Não encontramos esse produto.", 14, GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(24), dp(12), dp(24));
            results.addView(empty);
        }
    }

    private View productCard(final Product product) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(background(Color.WHITE, 16));

        card.addView(title(product.name, 18));
        card.addView(label("Código: " + product.code, 13, GRAY));
        card.addView(label("🏷️ " + product.lots.size() + " lote(s)", 14, BLUE));

        for (Lot lot : product.lots) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setBackground(background(Color.rgb(239, 246, 255), 10));
            row.addView(title("Lote: " + lot.lot, 15));
            row.addView(label("📍 " + lot.pos + "    📦 " + lot.qty + " un.", 14, DARK));
            card.addView(row, marginParams(0, 6, 0, 0));
        }

        card.setOnClickListener(v -> productDetails(product));
        return card;
    }

    private void productDetails(final Product product) {
        base("Produto", "Gerencie os lotes, posições e quantidades");
        box.addView(title(product.name, 21));
        box.addView(label("Código: " + product.code, 14, GRAY), marginParams(0, 2, 0, 12));
        box.addView(sectionTitle("Lotes"));

        if (product.lots.isEmpty()) {
            box.addView(label("Nenhum lote cadastrado.", 14, GRAY), marginParams(0, 4, 0, 10));
        } else {
            for (Lot lot : new ArrayList<>(product.lots)) {
                addLotRow(product, lot);
            }
        }

        Button addLot = actionButton("➕ Adicionar lote");
        addLot.setOnClickListener(v -> addLotDialog(product));
        box.addView(addLot, marginParams(0, 10, 0, 8));

        Button edit = actionButton("✏️ Editar produto");
        edit.setOnClickListener(v -> editProductDialog(product));
        box.addView(edit, marginParams(0, 0, 0, 8));

        Button delete = dangerButton("🗑️ Excluir produto");
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Excluir produto?")
                .setMessage("Isso removerá o produto e todos os seus lotes.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> {
                    products.remove(product);
                    saveProducts();
                    home();
                })
                .show());
        box.addView(delete, marginParams(0, 0, 0, 8));

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private void addLotRow(final Product product, final Lot lot) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(background(Color.WHITE, 12));
        row.addView(title("🏷️ Lote: " + lot.lot, 16));
        row.addView(label("📍 Posição: " + lot.pos + "   •   📦 Quantidade: " + lot.qty, 14, DARK));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button edit = actionButton("✏️ Editar lote");
        edit.setOnClickListener(v -> editLotDialog(product, lot));
        Button delete = dangerButton("Excluir");
        delete.setOnClickListener(v -> {
            product.lots.remove(lot);
            saveProducts();
            productDetails(product);
        });

        buttons.addView(edit, new LinearLayout.LayoutParams(0, dp(52), 1));
        buttons.addView(delete, new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(buttons, marginParams(0, 8, 0, 0));
        box.addView(row, marginParams(0, 0, 0, 8));
    }

    private void newProduct() {
        final EditText name = field("Nome do produto");
        final EditText code = field("Código/SKU (opcional)");

        LinearLayout content = dialogContent();
        content.addView(name);
        content.addView(code, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle("Cadastrar produto")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar", (dialog, which) -> {
                    String productName = name.getText().toString().trim();
                    if (productName.isEmpty()) {
                        Toast.makeText(this, "Informe o nome do produto.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Product product = new Product(code.getText().toString().trim(), productName);
                    products.add(product);
                    sortProducts();
                    saveProducts();
                    addLotDialog(product);
                })
                .show();
    }

    private LinearLayout dialogContent() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(8), dp(4), dp(8), dp(4));
        return layout;
    }

    private EditText field(String hint) {
        EditText editText = new EditText(this);
        editText.setHint(hint);
        editText.setSingleLine(true);
        editText.setTextSize(16);
        return editText;
    }

    private void editProductDialog(final Product product) {
        LinearLayout content = dialogContent();
        EditText name = field("Nome do produto");
        EditText code = field("Código/SKU");
        name.setText(product.name);
        code.setText(product.code);
        content.addView(name);
        content.addView(code, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle("Editar produto")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String newName = name.getText().toString().trim();
                    if (newName.isEmpty()) {
                        Toast.makeText(this, "Informe o nome do produto.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    product.name = newName;
                    product.code = code.getText().toString().trim();
                    sortProducts();
                    saveProducts();
                    productDetails(product);
                })
                .show();
    }

    private void addLotDialog(Product product) {
        lotDialog(product, null);
    }

    private void editLotDialog(Product product, Lot lot) {
        lotDialog(product, lot);
    }

    private void lotDialog(final Product product, final Lot oldLot) {
        LinearLayout content = dialogContent();
        EditText lot = field("Lote");
        EditText position = field("Posição no estoque");
        EditText quantity = field("Quantidade");
        quantity.setInputType(InputType.TYPE_CLASS_NUMBER);

        if (oldLot != null) {
            lot.setText(oldLot.lot);
            position.setText(oldLot.pos);
            quantity.setText(String.valueOf(oldLot.qty));
        }

        content.addView(lot);
        content.addView(position, marginParams(0, 8, 0, 0));
        content.addView(quantity, marginParams(0, 8, 0, 0));

        new AlertDialog.Builder(this)
                .setTitle(oldLot == null ? "Adicionar lote" : "Editar lote")
                .setView(content)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (dialog, which) -> {
                    String lotValue = lot.getText().toString().trim();
                    String positionValue = position.getText().toString().trim();
                    String quantityValue = quantity.getText().toString().trim();

                    if (lotValue.isEmpty() || positionValue.isEmpty() || quantityValue.isEmpty()) {
                        Toast.makeText(this, "Preencha lote, posição e quantidade.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        int quantityNumber = Integer.parseInt(quantityValue);
                        if (quantityNumber < 0) {
                            throw new NumberFormatException();
                        }

                        if (oldLot == null) {
                            product.lots.add(new Lot(lotValue, positionValue, quantityNumber));
                        } else {
                            oldLot.lot = lotValue;
                            oldLot.pos = positionValue;
                            oldLot.qty = quantityNumber;
                        }

                        saveProducts();
                        productDetails(product);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "A quantidade deve ser um número válido.", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private TextView sectionTitle(String text) {
        TextView view = title(text, 18);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        return view;
    }

    private void catalog() {
        base("Produtos cadastrados", "Produtos e todos os seus lotes");
        if (products.isEmpty()) {
            box.addView(label("Nenhum produto cadastrado.", 14, GRAY));
        } else {
            for (Product product : products) {
                box.addView(productCard(product), marginParams(0, 0, 0, 10));
            }
        }

        Button back = actionButton("⬅ Voltar para busca");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private void picking() {
        base("Picking • NF-e 000123", "Separe os produtos seguindo as posições");
        final int[] separated = {0};
        final ArrayList<Product> pickingProducts = new ArrayList<>();
        for (Product product : products) {
            if (!product.lots.isEmpty()) {
                pickingProducts.add(product);
            }
        }

        final TextView progress = title("Progresso: 0/" + pickingProducts.size() + " produtos", 18);
        box.addView(progress, marginParams(0, 0, 0, 10));

        for (Product product : pickingProducts) {
            Lot lot = product.lots.get(0);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(background(Color.WHITE, 14));
            card.addView(title(product.name + " • " + lot.qty + " un.", 18));
            card.addView(label("🏷️ Lote: " + lot.lot + "\n📍 Posição: " + lot.pos + "\nCódigo: " + product.code, 15, DARK));

            Button done = actionButton("Marcar como separado");
            done.setOnClickListener(v -> {
                if (done.isEnabled()) {
                    separated[0]++;
                    done.setText("✅ Separado");
                    done.setEnabled(false);
                    progress.setText("Progresso: " + separated[0] + "/" + pickingProducts.size() + " produtos");
                }
            });
            card.addView(done, marginParams(0, 8, 0, 0));
            box.addView(card, marginParams(0, 0, 0, 10));
        }

        Button back = actionButton("⬅ Voltar");
        back.setOnClickListener(v -> home());
        box.addView(back);
    }

    private static class Lot {
        String lot;
        String pos;
        int qty;

        Lot(String lot, String pos, int qty) {
            this.lot = lot;
            this.pos = pos;
            this.qty = qty;
        }
    }

    private static class Product {
        String code;
        String name;
        ArrayList<Lot> lots = new ArrayList<>();

        Product(String code, String name) {
            this.code = code;
            this.name = name;
        }

        boolean matches(String query) {
            if (name.toLowerCase(Locale.ROOT).contains(query)) {
                return true;
            }
            if (code.toLowerCase(Locale.ROOT).contains(query)) {
                return true;
            }
            for (Lot lot : lots) {
                if (lot.lot.toLowerCase(Locale.ROOT).contains(query)
                        || lot.pos.toLowerCase(Locale.ROOT).contains(query)) {
                    return true;
                }
            }
            return false;
        }
    }
}
