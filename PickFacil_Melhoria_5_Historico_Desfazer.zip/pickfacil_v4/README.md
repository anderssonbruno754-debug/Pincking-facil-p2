# Pick Fácil — Melhoria 5: Histórico e Desfazer Coleta

Versão do aplicativo com cadastro de produtos, vários lotes por produto, posição e quantidade, pesquisa e leitura de nota por foto.

## Coleta por foto
1. Toque em **Coletar por foto da nota**.
2. Permita acesso à câmera.
3. Fotografe a nota.
4. O aplicativo usa OCR do Google ML Kit para reconhecer o texto no próprio aparelho.
5. Produtos já cadastrados são procurados no texto e organizados pela posição.
6. Quando a quantidade for identificada, ela é distribuída pelos lotes disponíveis.
7. Use **Ver texto lido da foto** para conferir o OCR.

Esta é uma primeira versão de automação: notas com layouts diferentes podem exigir ajustes no reconhecimento de quantidade e nome.


## Melhoria 4 — Lista inteligente de coleta

- Organiza os itens reconhecidos pela foto em ordem de posição.
- Permite marcar cada item como coletado.
- Ao marcar, baixa automaticamente a quantidade do lote no estoque.
- Mostra progresso por itens e unidades.
- Permite conferir o estoque atualizado.

Fluxo: fotografar nota → reconhecer produtos → ordenar por posição → coletar → marcar como coletado → baixar estoque.


## Melhoria 5 — Histórico e desfazer

- Registra cada item baixado no estoque com data e hora.
- Guarda produto, lote, posição e quantidade da baixa.
- Tela **Histórico de coletas** na página inicial.
- Permite **Desfazer esta baixa** e devolver a quantidade ao mesmo lote/posição.
- Uma baixa desfeita fica identificada no histórico e não pode ser desfeita novamente.
- Limpar o histórico não altera o estoque.

O fluxo agora é: fotografar nota → montar lista → coletar → baixa automática → histórico → desfazer quando necessário.
