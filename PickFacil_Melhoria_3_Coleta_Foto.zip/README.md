# Pick Fácil — Melhoria 3: Coleta por foto

Esta versão mantém o cadastro de produtos, vários lotes, posições, quantidades e pesquisa da versão anterior.

## Nova função

Na tela inicial foi adicionada a opção **📷 Coletar por foto da nota**.

Fluxo:
1. O usuário tira uma foto da nota de saída.
2. O aplicativo usa reconhecimento de texto (ML Kit) para ler a imagem no próprio aparelho.
3. O texto é comparado com os produtos cadastrados.
4. As quantidades identificadas são distribuídas entre os lotes disponíveis.
5. A coleta é organizada por posição.
6. Ao marcar um item como separado, a quantidade é baixada do lote correspondente.

## Observação

Esta é a primeira versão de teste do OCR. A precisão depende da qualidade da foto e do padrão da nota. A tela também permite consultar o texto reconhecido para facilitar os testes.
