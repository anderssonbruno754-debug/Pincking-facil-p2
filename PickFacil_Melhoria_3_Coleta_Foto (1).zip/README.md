# Pick Fácil — Melhoria 3: Coleta por Foto

Versão do aplicativo com cadastro de produtos, vários lotes por produto, posição e quantidade, pesquisa e leitura de nota por foto.

## Coleta por foto
1. Toque em **Coletar por foto da nota**.
2. Permita acesso à câmera.
3. Fotografe a nota.
4. O aplicativo usa OCR do Google ML Kit para reconhecer o texto no próprio aparelho.
5. Produtos já cadastrados são procurados no texto e organizados pela posição.
6. Quando a quantidade for identificada, ela é distribuída pelos lotes disponíveis.
7. Use **Ver texto lido da foto** para conferir o OCR.

Esta é uma primeira versão de automação: notas com layouts diferentes podem exigir ajustes no reconhecimento de quantidade e nome.
